using System.Runtime.CompilerServices;
[assembly:InternalsVisibleTo("lilToon.Editor.External")]
